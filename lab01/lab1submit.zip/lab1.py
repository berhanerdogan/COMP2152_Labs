# Sample Coding Questions 01 Week 01
# Berhan Erdogan

vars = [1, 4, 7, 9]

a = 1
b = 2
c = 3
d = 4

e = ((a - ((b ** c) // d)) + (a % c))

temperature = 32.6
output = f"he temperature today is: {temperature:.3f} degrees Celsius"
print(output)

userAge = int(input("Enter your age: "))
userAge = userAge + 22
print(f"Now showing thee shop items filtered by age: {userAge} ")